import React from 'react';

const DocumentsScreen = () => {
  return <div>DocumentsScreen</div>;
};

export default DocumentsScreen;
