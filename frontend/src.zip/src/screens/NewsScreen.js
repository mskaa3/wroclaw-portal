import React from 'react';

const NewsScreen = () => {
  return <div>NewsScreen</div>;
};

export default NewsScreen;
