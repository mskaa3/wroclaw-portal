import React from 'react';

const LoginScreen = () => {
  return <div>LoginScreen</div>;
};

export default LoginScreen;
