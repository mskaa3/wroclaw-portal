/* eslint-disable prettier/prettier */
import React from 'react';
import QAform from '../components/QAform';

const QaScreen = () => {
  return (
    <div>
      <QAform />
    </div>
  )
};


export default QaScreen;
