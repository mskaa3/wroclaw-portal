import React from 'react';
import TopImage from '../components/TopImage';

const HomeScreen = () => {
  return <TopImage />;
};

export default HomeScreen;
