/* eslint-disable prettier/prettier */
import React from 'react';
import ForumTopics from '../components/ForumTopics';


const ForumScreen = () => {
  return(
  <div>
      <ForumTopics />
    </div>
    )
};

export default ForumScreen;
